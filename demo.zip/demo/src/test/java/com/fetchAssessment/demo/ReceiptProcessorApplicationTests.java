package com.fetchAssessment.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReceiptProcessorApplicationTests {

	@Test
	void contextLoads() {
	}

}
